package com.example.marsincv4;

public class Weather {
}
