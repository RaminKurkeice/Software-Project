package com.example.myapplication;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

public class SettingsTest {
    private Settings mSettings;

    @Before
    public void setUp() throws Exception {
        mSettings = new Settings();
    }

    @Test
    public void testSum() throws Exception {

        assertEquals(0,mSettings.set(0));
        assertEquals(1,mSettings.set(1));
        assertEquals(2,mSettings.set(2));

    }


}
